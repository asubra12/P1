
public class CookingStation extends CLList<CookingItem> implements CookingStationInterface { 
    
    public String stationname;
    
    public CookingStation(String name) {
        stationname = name;
    }
    
    /** Put a new dish at the end of the station.
     *  @param it the dish to add
     */
    public void addItem(CookingItem it) {
        this.insert(it);
    };

    /** Simulate one minute time passing for this station.
     */
    public void tick() {
//        int curr = this.currPos();
//        this.moveToStart();
        for (int i = 0; i < this.length(); i++) {
            this.getValue().tick();
            this.next();
        }
        
//        this.moveToPos(curr);
    };

    /** Tend the current item
     *  @param removeThreshold the number of minutes that may be used to 
     *            determine if an item should be removed from the station.
     *  @param penaltyThreshold the limit on the penalty value that may be
                  used to determine if an item should be removed from the station.
     *  @return the item if you decide to remove it, or null otherwise
     */
    
    public CookingItem tend(int removeThreshold, int penaltyThreshold) {
        int time = this.getCurrValue().timeleft;
        
        if (time <= removeThreshold) {
            return this.remove();
        } else if (this.getValue().penalty() <= penaltyThreshold) {
            return this.remove();
        } else {
            return null;
        }
    };
    
    @Override
    public String toString() {
        int pos = this.currPos();
        
        this.moveToStart();
        
        int stationlen = this.length();
        
        StringBuilder station = new StringBuilder();
        station.append("[ " + this.stationname + " [ ");
        for (int i = 0; i < stationlen; i++) {
            CookingItem curr = this.getCurrValue();
            station.append("(" + curr.getName() + " " + curr.timeleft + ") ");
            this.next();
        }
        station.append("] ");
        
        this.moveToPos(pos);
        
        return station.toString();
    }
    
    public static void main(String[] args) {
        CookingStation a = new CookingStation("Stove");
        CookingItem b = new CookingItem("Spaghetti", 10, 2, 3);
        CookingItem c = new CookingItem("Ravioli", 20, 1, 2);
        CookingItem d = new CookingItem("Linguini", 10, 2, 2);
        
        a.append(b);
        a.append(c);
       
        a.tick();
        a.tend(2, 1);
        System.out.println(a);
        
        a.tick();
        a.tend(2, 1);
        System.out.println(a);
        
        a.tend(2, 1);
        System.out.println(a);
        
    }
}
