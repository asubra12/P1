public class CookingItem implements CookingItemInterface {
        
        private String itemname;
        public int cookingtime;
        public int underdonepenalty;
        public int overdonepenalty;
        public int timeleft;
        
        public CookingItem(String it, int ct, int udp, int odp) {
            itemname = it;
            cookingtime = ct;
            underdonepenalty = udp;
            overdonepenalty = odp;
            timeleft = ct;
        }
        
        public void tick() {
            timeleft -= 1;

        }

        public int timeRemaining() {
            return timeleft;
        }

        public int penalty() {
            if (timeleft < 0) {
                int pen = timeleft * overdonepenalty * -1;
                return pen;
            } else if (timeleft > 0) {
                int pen = timeleft * underdonepenalty;
                return pen;
            } else {
                return 0;
            }    
        }
        
        public String getName() {
            return itemname;
        }
         
    }